#   THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR
#   IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
#   FOR A PARTICULAR PURPOSE. THIS CODE AND INFORMATION ARE NOT SUPPORTED BY XEBIALABS.
### rules/server-cleanup.py

# Funtion to find the hosts in a WebSphere Custer
def findHosts(container):
    hosts = []
    ctype = str(container.type)
    if ctype == "was.ManagerServer":
        hosts.push(container.node.host)
    elif ctype == "was.Cluster":
        hosts = [server.node.host for server in container.servers]
    return hosts

# Function to create a cleanup step
def createCleanupStep(host):
    return steps.os_script(order = 72, script='rules/cleanupWebsphere', freemarker_context = {"host":host}, target_host=host, description = "Perform clean up on host " + host.name)

# Main
for host in findHosts(deployed.container):
    context.addStep(createCleanupStep(host))
